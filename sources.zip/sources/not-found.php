<?php 
$music->site_title = 'Home';
$music->site_description = $music->config->description;
$music->site_pagename = "404";
$music->site_content = loadPage("404/content");