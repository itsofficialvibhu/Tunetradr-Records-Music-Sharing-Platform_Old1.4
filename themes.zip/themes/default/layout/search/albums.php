<section class="search_result_count">5 results for: <b>ariana</b></section>
<div class="sq_music_tracks search_albums">
	<div class="sq_track_slider no-slider">
		<div class="track_list">
			<div class="track">
				<div class="cover_art">
					<a href="single_song.php">
						<img src="assets/img/songs/song_1.jpg" />
						<div class="play_btn">
							<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24"><path fill="currentColor" d="M10,16.5V7.5L16,12M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z"></path></svg>
						</div>
					</a>
				</div>
				<div class="track_info">
					<a href="single_song.php"><span class="title">Goodbye (feat. Nicki Minaj & Willy William)</span></a>
					<a href="artist.php"><span class="artist">Jason Derulo</span></a>
				</div>
			</div>
		</div>
		<div class="track_list">
			<div class="track">
				<div class="cover_art">
					<a href="single_song.php">
						<img src="assets/img/songs/song_2.jpg" />
						<div class="play_btn">
							<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24"><path fill="currentColor" d="M10,16.5V7.5L16,12M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z"></path></svg>
						</div>
					</a>
				</div>
				<div class="track_info">
					<a href="single_song.php"><span class="title">Right Now</span></a>
					<a href="artist.php"><span class="artist">Nick Jonas</span></a>
				</div>
			</div>
		</div>
		<div class="track_list">
			<div class="track">
				<div class="cover_art">
					<a href="single_song.php">
						<img src="assets/img/songs/song_3.jpg" />
						<div class="play_btn">
							<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24"><path fill="currentColor" d="M10,16.5V7.5L16,12M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z"></path></svg>
						</div>
					</a>
				</div>
				<div class="track_info">
					<a href="single_song.php"><span class="title">Love Yourself 結 'answer'</span></a>
					<a href="artist.php"><span class="artist">BTS</span></a>
				</div>
			</div>
		</div>
		<div class="track_list">
			<div class="track">
				<div class="cover_art">
					<a href="single_song.php">
						<img src="assets/img/songs/song_4.jpg" />
						<div class="play_btn">
							<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24"><path fill="currentColor" d="M10,16.5V7.5L16,12M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z"></path></svg>
						</div>
					</a>
				</div>
				<div class="track_info">
					<a href="single_song.php"><span class="title">Save Yourself</span></a>
					<a href="artist.php"><span class="artist">The Chainsmokers</span></a>
				</div>
			</div>
		</div>
		<div class="track_list">
			<div class="track">
				<div class="cover_art">
					<a href="single_song.php">
						<img src="assets/img/songs/song_5.jpg" />
						<div class="play_btn">
							<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24"><path fill="currentColor" d="M10,16.5V7.5L16,12M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z"></path></svg>
						</div>
					</a>
				</div>
				<div class="track_info">
					<a href="single_song.php"><span class="title">Drive</span></a>
					<a href="artist.php"><span class="artist">David Guetta</span></a>
				</div>
			</div>
		</div>
		<div class="track_list">
			<div class="track">
				<div class="cover_art">
					<a href="single_song.php">
						<img src="assets/img/songs/song_6.jpg" />
						<div class="play_btn">
							<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24"><path fill="currentColor" d="M10,16.5V7.5L16,12M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z"></path></svg>
						</div>
					</a>
				</div>
				<div class="track_info">
					<a href="single_song.php"><span class="title">First Time - EP</span></a>
					<a href="artist.php"><span class="artist">Liam Payne</span></a>
				</div>
			</div>
		</div>
		<div class="track_list">
			<div class="track">
				<div class="cover_art">
					<a href="single_song.php">
						<img src="assets/img/songs/song_7.jpg" />
						<div class="play_btn">
							<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24"><path fill="currentColor" d="M10,16.5V7.5L16,12M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z"></path></svg>
						</div>
					</a>
				</div>
				<div class="track_info">
					<a href="single_song.php"><span class="title">Promises</span></a>
					<a href="artist.php"><span class="artist">Adam Wiles</span></a>
				</div>
			</div>
		</div>
		<div class="track_list">
			<div class="track">
				<div class="cover_art">
					<a href="single_song.php">
						<img src="assets/img/songs/song_3.jpg" />
						<div class="play_btn">
							<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24"><path fill="currentColor" d="M10,16.5V7.5L16,12M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z"></path></svg>
						</div>
					</a>
				</div>
				<div class="track_info">
					<a href="single_song.php"><span class="title">Goodbye (feat. Nicki Minaj & Willy William)</span></a>
					<a href="artist.php"><span class="artist">Jason Derulo</span></a>
				</div>
			</div>
		</div>
		<div class="track_list">
			<div class="track">
				<div class="cover_art">
					<a href="single_song.php">
						<img src="assets/img/songs/song_6.jpg" />
						<div class="play_btn">
							<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24"><path fill="currentColor" d="M10,16.5V7.5L16,12M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z"></path></svg>
						</div>
					</a>
				</div>
				<div class="track_info">
					<a href="single_song.php"><span class="title">Goodbye (feat. Nicki Minaj & Willy William)</span></a>
					<a href="artist.php"><span class="artist">Jason Derulo</span></a>
				</div>
			</div>
		</div>
		<div class="track_list">
			<div class="track">
				<div class="cover_art">
					<a href="single_song.php">
						<img src="assets/img/songs/song_1.jpg" />
						<div class="play_btn">
							<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24"><path fill="currentColor" d="M10,16.5V7.5L16,12M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z"></path></svg>
						</div>
					</a>
				</div>
				<div class="track_info">
					<a href="single_song.php"><span class="title">Goodbye (feat. Nicki Minaj & Willy William)</span></a>
					<a href="artist.php"><span class="artist">Jason Derulo</span></a>
				</div>
			</div>
		</div>
		<div class="track_list">
			<div class="track">
				<div class="cover_art">
					<a href="single_song.php">
						<img src="assets/img/songs/song_2.jpg" />
						<div class="play_btn">
							<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24"><path fill="currentColor" d="M10,16.5V7.5L16,12M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z"></path></svg>
						</div>
					</a>
				</div>
				<div class="track_info">
					<a href="single_song.php"><span class="title">Goodbye (feat. Nicki Minaj & Willy William)</span></a>
					<a href="artist.php"><span class="artist">Jason Derulo</span></a>
				</div>
			</div>
		</div>
	</div>
</div>