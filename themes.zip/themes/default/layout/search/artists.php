<section class="search_result_count">5 results for: <b>ariana</b></section>
<div class="artist_section search_artists">
	<div class="artist_list">
		<div class="cover_art">
			<a href="artist.php">
				<img src="assets/img/artists/artist_1.jpg">
			</a>
		</div>
		<div class="track_info">
			<a href="artist.php"><span class="artist">Alan Walker</span></a>
		</div>
	</div>
	<div class="artist_list">
		<div class="cover_art">
			<a href="artist.php">
				<img src="assets/img/artists/artist_2.jpg">
			</a>
		</div>
		<div class="track_info">
			<a href="artist.php"><span class="artist">Taylor Swift</span></a>
		</div>
	</div>
	<div class="artist_list">
		<div class="cover_art">
			<a href="artist.php">
				<img src="assets/img/artists/artist_3.jpg">
			</a>
		</div>
		<div class="track_info">
			<a href="artist.php"><span class="artist">JoJo</span></a>
		</div>
	</div>
	<div class="artist_list">
		<div class="cover_art">
			<a href="artist.php">
				<img src="assets/img/artists/artist_4.jpg">
			</a>
		</div>
		<div class="track_info">
			<a href="artist.php"><span class="artist">Eminem</span></a>
		</div>
	</div>
	<div class="artist_list">
		<div class="cover_art">
			<a href="artist.php">
				<img src="assets/img/artists/artist_5.jpg">
			</a>
		</div>
		<div class="track_info">
			<a href="artist.php"><span class="artist">Dua Lipa</span></a>
		</div>
	</div>
	<div class="artist_list">
		<div class="cover_art">
			<a href="artist.php">
				<img src="assets/img/artists/artist_6.jpg">
			</a>
		</div>
		<div class="track_info">
			<a href="artist.php"><span class="artist">Ariana Grande</span></a>
		</div>
	</div>
	<div class="artist_list">
		<div class="cover_art">
			<a href="artist.php">
				<img src="assets/img/artists/artist_7.jpg">
			</a>
		</div>
		<div class="track_info">
			<a href="artist.php"><span class="artist">Justin Bieber</span></a>
		</div>
	</div>
	<div class="artist_list">
		<div class="cover_art">
			<a href="artist.php">
				<img src="assets/img/artists/artist_7.jpg">
			</a>
		</div>
		<div class="track_info">
			<a href="artist.php"><span class="artist">Justin Bieber</span></a>
		</div>
	</div>
	<div class="artist_list">
		<div class="cover_art">
			<a href="artist.php">
				<img src="assets/img/artists/artist_6.jpg">
			</a>
		</div>
		<div class="track_info">
			<a href="artist.php"><span class="artist">Ariana Grande</span></a>
		</div>
	</div>
	<div class="artist_list">
		<div class="cover_art">
			<a href="artist.php">
				<img src="assets/img/artists/artist_5.jpg">
			</a>
		</div>
		<div class="track_info">
			<a href="artist.php"><span class="artist">Dua Lipa</span></a>
		</div>
	</div>
	<div class="artist_list">
		<div class="cover_art">
			<a href="artist.php">
				<img src="assets/img/artists/artist_4.jpg">
			</a>
		</div>
		<div class="track_info">
			<a href="artist.php"><span class="artist">Eminem</span></a>
		</div>
	</div>
	<div class="artist_list">
		<div class="cover_art">
			<a href="artist.php">
				<img src="assets/img/artists/artist_3.jpg">
			</a>
		</div>
		<div class="track_info">
			<a href="artist.php"><span class="artist">JoJo</span></a>
		</div>
	</div>
	<div class="artist_list">
		<div class="cover_art">
			<a href="artist.php">
				<img src="assets/img/artists/artist_2.jpg">
			</a>
		</div>
		<div class="track_info">
			<a href="artist.php"><span class="artist">Taylor Swift</span></a>
		</div>
	</div>
	<div class="artist_list">
		<div class="cover_art">
			<a href="artist.php">
				<img src="assets/img/artists/artist_1.jpg">
			</a>
		</div>
		<div class="track_info">
			<a href="artist.php"><span class="artist">Alan Walker</span></a>
		</div>
	</div>
</div>