<?php
$themeName = 'default';
$themeVirsion = '1.0.0';
$themeAuthor = 'deepsound';
$themeAuthorUrl = 'https://www.deepsoundscript.com';