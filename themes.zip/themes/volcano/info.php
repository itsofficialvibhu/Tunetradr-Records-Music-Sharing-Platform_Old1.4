<?php
$themeName = 'Volcano';
$themeVirsion = '1.0';
$themeAuthor = 'deepsound';
$themeAuthorUrl = 'https://deepsoundscript.com';